import './Description.css';

function Description() {
  return (
   <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid, laborum tempore earum sit rerum recusandae, eum ab repellat inventore possimus deleniti atque! Odit porro illum autem eos eaque accusantium veritatis.</p>
  );
}

export default Description;
